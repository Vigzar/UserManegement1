﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using UserManegement.Models;

namespace UserManegement
{
    public partial class TimeTrackingForm : Form
    {
        private User currentUser;
        private List<TimeEntry> timeEntries;
        private DateTime? timerStartTime;
        private TimeSpan totalTimerTime;

        public TimeTrackingForm(User user)
        {
            InitializeComponent();
            currentUser = user;
            timeEntries = new List<TimeEntry>();
            totalTimerTime = TimeSpan.Zero;

            InitializeForm();
            LoadTimeEntries();
        }

        private void InitializeForm()
        {
            this.Text = $"Учёт времени — {currentUser.Username}";

            cmbProject.Items.AddRange(new object[] { "Проект A", "Проект B", "Прочее" });
            cmbProject.SelectedIndex = 0;

            SetupDataGridView();

            timer1.Interval = 1000;
            timer1.Tick += Timer1_Tick;
        }

        private void SetupDataGridView()
        {
            dgvTimeEntries.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvTimeEntries.MultiSelect = false;
            dgvTimeEntries.AutoGenerateColumns = false;
            dgvTimeEntries.Columns.Clear();

            dgvTimeEntries.Columns.Add(new DataGridViewTextBoxColumn
            {
                Name = "SelectColumn",
                DataPropertyName = "EntryId",
                HeaderText = "ID",
                Width = 50,
                ReadOnly = true
            });

            dgvTimeEntries.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = "Date",
                HeaderText = "Дата",
                Width = 80
            });

            dgvTimeEntries.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = "Project",
                HeaderText = "Проект",
                Width = 120
            });

            dgvTimeEntries.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = "Hours",
                HeaderText = "Часы",
                Width = 60
            });

            dgvTimeEntries.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = "Description",
                HeaderText = "Описание",
                Width = 200
            });
        }

        private string connectionString = "Data Source=DJ-R118C03\\SQLEXPRESS;Initial Catalog=UserManagement;Integrated Security=True;Encrypt=False;";

        private void LoadTimeEntries()
        {
            try
            {
                dgvTimeEntries.Columns.Clear();
                dgvTimeEntries.Rows.Clear();
                using (var connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    string sqlQuery = "SELECT * FROM TimeEntries";

                    using (var command = new SqlCommand(sqlQuery, connection))
                    {
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            if (reader.HasRows)
                            {
                                dgvTimeEntries.Columns.Add("EntryId", "ID");
                                dgvTimeEntries.Columns.Add("Date", "Дата");
                                dgvTimeEntries.Columns.Add("Project", "Проект");
                                dgvTimeEntries.Columns.Add("Hours", "Часы");
                                dgvTimeEntries.Columns.Add("Description", "Описание");

                                while (reader.Read())
                                {
                                    dgvTimeEntries.Rows.Add(
                                        reader["EntryId"],
                                        reader["Date"],
                                        reader["Project"],
                                        reader["Hours"],
                                        reader["Description"]
                                    );
                                }
                            }
                        }
                    }
                }
                UpdateStatus($"Загружено записей: {dgvTimeEntries.Rows.Count}");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки записей: {ex.Message}",
                    "Ошибка",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
        }

        private void UpdateStatus(string message)
        {
            lblStatus.Text = message;
        }

        private void btnStartTimer_Click(object sender, EventArgs e)
        {
            if (timerStartTime == null)
            {
                timerStartTime = DateTime.Now;
                timer1.Start();
                lblTimer.ForeColor = Color.Green;
                UpdateStatus("Таймер запущен");
            }
        }

        private void btnStopTimer_Click(object sender, EventArgs e)
        {
            if (timerStartTime.HasValue)
            {
                TimeSpan elapsed = DateTime.Now - timerStartTime.Value;
                totalTimerTime += elapsed;

                timer1.Stop();
                timerStartTime = null;
                lblTimer.Text = "00:00:00";
                lblTimer.ForeColor = Color.Black;

                AddTimeEntryFromTimer(elapsed);
                UpdateStatus("Таймер остановлен и запись добавлена");
            }
        }

        private void Timer1_Tick(object sender, EventArgs e)
        {
            if (timerStartTime.HasValue)
            {
                TimeSpan currentElapsed = DateTime.Now - timerStartTime.Value + totalTimerTime;
                lblTimer.Text = currentElapsed.ToString(@"hh\:mm\:ss");
            }
        }

        private void AddTimeEntryFromTimer(TimeSpan elapsed)
        {
            var newEntry = new TimeEntry
            {
                Date = DateTime.Now.Date,
                Project = cmbProject.SelectedItem.ToString(),
                Hours = elapsed.TotalHours,
                Description = $"Работа по таймеру: {elapsed.ToString(@"hh\:mm")}"
            };

            timeEntries.Add(newEntry);
            dgvTimeEntries.DataSource = null;
            dgvTimeEntries.DataSource = timeEntries;
        }

        private void btnAddEntry_Click(object sender, EventArgs e)
        {
            
            if (!double.TryParse(txtHours.Text, out double hours) || hours <= 0)
            {
                MessageBox.Show("Введите корректное количество часов", "Внимание",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string project = cmbProject.SelectedItem.ToString();
            DateTime date = dtpDate.Value.Date;
            string description = txtDescription.Text.Trim();

            string sqlQuery = "INSERT INTO TimeEntries (Date, Project, Hours, Description, UserId) VALUES (@date, @project, @hours, @description, @userId)";

            try
            {
                using (var connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    using (var command = new SqlCommand(sqlQuery, connection))
                    {
                        command.Parameters.AddWithValue("@date", date);
                        command.Parameters.AddWithValue("@project", project);
                        command.Parameters.AddWithValue("@hours", hours);
                        command.Parameters.AddWithValue("@description", description);
                        command.Parameters.AddWithValue("@userId", currentUser.UserId);


                        command.ExecuteNonQuery(); 
                    }
                }

            
                LoadTimeEntries(); 
                ClearInputFields();
                UpdateStatus($"Запись добавлена в базу: {hours} часов на {project}");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при сохранении в базу данных: {ex.Message}", "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void ClearInputFields()
        {
            txtHours.Clear();
            txtDescription.Clear();
            dtpDate.Value = DateTime.Now.Date;
            cmbProject.SelectedIndex = 0;
        }

        private void btnDeleteEntry_Click(object sender, EventArgs e)
        {
            if (dgvTimeEntries.SelectedRows.Count > 0)
            {
                int selectedRowIndex = dgvTimeEntries.SelectedRows[0].Index;

                int entryIdToDelete = Convert.ToInt32(dgvTimeEntries.Rows[selectedRowIndex].Cells["EntryId"].Value);

                if (MessageBox.Show($"Удалить запись?",
                    "Подтверждение удаления",
                    MessageBoxButtons.YesNo,
                    MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    try
                    {
                        using (var connection = new SqlConnection(connectionString))
                        {
                            connection.Open();

                            string sqlQuery = "DELETE FROM TimeEntries WHERE EntryId = @entryId";

                            using (var command = new SqlCommand(sqlQuery, connection))
                            {
                                command.Parameters.AddWithValue("@entryId", entryIdToDelete);
                                command.ExecuteNonQuery();
                            }
                        }
                        LoadTimeEntries();
                        UpdateStatus("Запись успешно удалена из базы данных.");
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"Ошибка при удалении из базы данных: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            else
            {
                MessageBox.Show("Выберите запись для удаления", "Внимание");
            }
        }
        private void btnRefresh_Click(object sender, EventArgs e)
        {
            dgvTimeEntries.Columns.Clear();
            dgvTimeEntries.Rows.Clear();
            LoadTimeEntries();
            UpdateStatus("Данные обновлены");
        }

        private void dgvTimeEntries_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                var selectedEntry = (TimeEntry)dgvTimeEntries.Rows[e.RowIndex].DataBoundItem;

                dtpDate.Value = selectedEntry.Date;
                cmbProject.SelectedItem = selectedEntry.Project;
                txtHours.Text = selectedEntry.Hours.ToString();
                txtDescription.Text = selectedEntry.Description;

                timeEntries.Remove(selectedEntry);
                dgvTimeEntries.DataSource = null;
                dgvTimeEntries.DataSource = timeEntries;

                UpdateStatus($"Редактирование записи: {selectedEntry.Project}");
            }
        }

        private void UpdateTotalHours()
        {
            double totalHours = timeEntries.Sum(entry => entry.Hours);
            lblStatus.Text = $"Загружено записей: {timeEntries.Count}, Всего часов: {totalHours:F1}";
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            if (timer1.Enabled)
            {
                timer1.Stop();
            }
            base.OnFormClosing(e);
        }

        private void btnStopTimer_Click_1(object sender, EventArgs e)
        {

        }

        private void lblTimer_Click(object sender, EventArgs e)
        {

        }

        private void btnStartTimer_Click_1(object sender, EventArgs e)
        {

        }

        private void dgvTimeEntries_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void TimeTrackingForm_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "userManegementAppDataSet.WorkTime". При необходимости она может быть перемещена или удалена.
            this.workTimeTableAdapter.Fill(this.userManegementAppDataSet.WorkTime);

        }
    }
}
