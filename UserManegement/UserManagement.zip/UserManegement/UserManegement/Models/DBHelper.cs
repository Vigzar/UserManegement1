﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Reflection;
using UserManegement.Models;

public static class DBHelper
{
    public static string ConnectionString = "Data Source=DJ-R118C03\\SQLEXPRESS;Initial Catalog=UserManagement;Integrated Security=True;Encrypt=False";

    public static List<UserManegement.Models.Task> GetTasksByUserId(int userId)
    {
        List<UserManegement.Models.Task> tasks = new List<UserManegement.Models.Task>();
        string query = @"SELECT TaskId, Name, Priority, DueDate, IsCompleted
               FROM Tasks
               WHERE AssignedTo = @UserId
               ORDER BY DueDate";

        using (SqlConnection conn = new SqlConnection(ConnectionString))
        {
            using (SqlCommand cmd = new SqlCommand(query, conn))
            {
                cmd.Parameters.AddWithValue("@UserId", userId);
                conn.Open();
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        tasks.Add(new UserManegement.Models.Task
                        {
                            TaskId = reader.GetInt32(0),
                            Name = reader.GetString(1),
                            Priority = reader.GetString(2),
                            DueDate = reader.GetDateTime(3),
                            IsCompleted = reader.GetBoolean(4)
                        });
                    }
                }
            }
        }
        return tasks;
    }


    public static bool AddTask(UserManegement.Models.Task task, int userId)
    {
        string insertQuery = @"INSERT INTO Tasks (Name, Priority, DueDate, IsCompleted, AssignedTo)
                   VALUES (@Name, @Priority, @DueDate, @IsCompleted, @AssignedTo)";

        using (SqlConnection conn = new SqlConnection(ConnectionString))
        {
            using (SqlCommand cmd = new SqlCommand(insertQuery, conn))
            {
                cmd.Parameters.AddWithValue("@Name", task.Name);
                cmd.Parameters.AddWithValue("@Priority", task.Priority);
                cmd.Parameters.AddWithValue("@DueDate", task.DueDate);
                cmd.Parameters.AddWithValue("@IsCompleted", task.IsCompleted);
                cmd.Parameters.AddWithValue("@AssignedTo", userId);

                conn.Open();
                return cmd.ExecuteNonQuery() > 0;
            }
        }
    }
    public static List<WorkTimeRecord> GetWorkTimeByUserId(int userId)
    {
        List<WorkTimeRecord> workTimes = new List<WorkTimeRecord>();
        string query = @"SELECT WorkTimeId, UserId, TaskId, StartTime, EndTime, BreakMinutes, Date
                   FROM WorkTime
                   WHERE UserId = @UserId
                   ORDER BY Date DESC, StartTime";

        using (SqlConnection conn = new SqlConnection(ConnectionString))
        {
            using (SqlCommand cmd = new SqlCommand(query, conn))
            {
                cmd.Parameters.AddWithValue("@UserId", userId);
                conn.Open();
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        workTimes.Add(new WorkTimeRecord
                        {
                            RecordId = reader.GetInt32(0),
                            UserId = reader.GetInt32(1),
                            TaskId = reader.GetInt32(2),
                            StartTime = reader.GetDateTime(3),
                            EndTime = reader.IsDBNull(4) ? (DateTime?)null : reader.GetDateTime(4),
                            BreakMinutes = reader.GetInt32(5),
                            WorkDate = reader.GetDateTime(6)
                        });
                    }
                }
            }
            return workTimes;
        }
    }


    public static bool DeleteTask(int taskId)
    {
        string deleteQuery = "DELETE FROM Tasks WHERE TaskId = @TaskId";
        using (SqlConnection conn = new SqlConnection(ConnectionString))
        {
            using (SqlCommand cmd = new SqlCommand(deleteQuery, conn))
            {
                cmd.Parameters.AddWithValue("@TaskId", taskId);
                conn.Open();
                return cmd.ExecuteNonQuery() > 0;
            }
        }
    }
}
