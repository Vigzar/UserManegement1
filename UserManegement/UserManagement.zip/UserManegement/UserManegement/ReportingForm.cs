﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Windows.Forms;
using UserManegement.Models;

namespace UserManegement
{
    public partial class ReportingForm : Form
    {
        private User currentUser;
        private string connectionString = "Data Source=DJ-R118C03\\SQLEXPRESS;Initial Catalog=UserManagement;Integrated Security=True;Encrypt=False;";

        public ReportingForm(User user)
        {
            InitializeComponent();
            currentUser = user;
            dtpStartDate.Value = DateTime.Now.AddDays(-7);
            dtpEndDate.Value = DateTime.Now;
        }

        private void btnGenerateReport_Click(object sender, EventArgs e)
        {
            LoadReportData();
        }

        private void LoadReportData()
        {
            
            cmbReportType.Items.Add("По дням");
            cmbReportType.Items.Add("По проектам");
            cmbReportType.Items.Add("Общий отчёт");
            cmbReportType.SelectedIndex = 0;


            try
            {
                var startDate = dtpStartDate.Value.Date;
                var endDate = dtpEndDate.Value.Date.AddDays(1).AddSeconds(-1);
                string sqlQuery = "";

                switch (cmbReportType.SelectedItem.ToString())
                {
                    case "По дням":
                        sqlQuery = @"
                    SELECT Date, SUM(Hours) as TotalHours
                    FROM TimeEntries
                    WHERE UserId = @userId
                    AND Date BETWEEN @startDate AND @endDate
                    GROUP BY Date
                    ORDER BY Date";
                        break;
                    case "По проектам":
                        sqlQuery = @"
                    SELECT Project, SUM(Hours) as TotalHours
                    FROM TimeEntries
                    WHERE UserId = @userId
                    AND Date BETWEEN @startDate AND @endDate
                    GROUP BY Project
                    ORDER BY TotalHours DESC";
                        break;
                    default: 
                        sqlQuery = @"
                    SELECT EntryId, Date, Project, Hours, Description
                    FROM TimeEntries
                    WHERE UserId = @userId
                    AND Date BETWEEN @startDate AND @endDate
                    ORDER BY Date DESC";
                        break;
                }

                using (var connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    using (var command = new SqlCommand(sqlQuery, connection))
                    {
                        command.Parameters.AddWithValue("@userId", currentUser.UserId);
                        command.Parameters.AddWithValue("@startDate", startDate);
                        command.Parameters.AddWithValue("@endDate", endDate);

                        var adapter = new SqlDataAdapter(command);
                        var dataTable = new DataTable();
                        adapter.Fill(dataTable);
                        dgvReport.DataSource = dataTable;


                        double totalHours = dataTable.AsEnumerable()
                            .Sum(row => Convert.ToDouble(row["TotalHours"] ?? 0));
                        lblTotalHours.Text = $"Всего часов: {totalHours:F2}";
                        UpdateStatus($"Отчёт сформирован: {dataTable.Rows.Count} записей");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }


        private void UpdateStatus(string message)
        {
            lblStatus.Text = message;
        }

        private void cmbReportType_PreviewKeyDown(object sender, PreviewKeyDownEventArgs e)
        {

        }
    }
}
