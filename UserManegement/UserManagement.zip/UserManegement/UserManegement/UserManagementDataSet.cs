﻿namespace UserManegement
{


    partial class UserManagementDataSet
    {
    }
}
