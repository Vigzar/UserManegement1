﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Windows.Forms;
using UserManegement.Models;

namespace UserManegement
{
    public partial class TaskManagementForm : Form
    {
        private User currentUser;
        private List<Models.Task> tasks;

        public TaskManagementForm(User user)
        {
            InitializeComponent();
            currentUser = user;
            tasks = new List<Models.Task>();
            InitializeForm();
            LoadTasksFromDatabase();
        }

        private void InitializeForm()
        {
            this.Text = $"Управление задачами — {currentUser.Username}";


            cmbPriority.Items.AddRange(new object[] { "Высокий", "Средний", "Низкий" });
            cmbPriority.SelectedIndex = 1;


            SetupDataGridView();
        }

        private void SetupDataGridView()
        {
            dgvTasks.AutoGenerateColumns = false;
            dgvTasks.Columns.Clear();

            dgvTasks.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = "TaskId",
                HeaderText = "ID",
                Width = 50,
                ReadOnly = true
            });

            dgvTasks.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = "Name",
                HeaderText = "Название задачи",
                Width = 200
            });

            dgvTasks.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = "Priority",
                HeaderText = "Приоритет",
                Width = 80
            });

            dgvTasks.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = "DueDate",
                HeaderText = "Срок",
                Width = 100
            });

            dgvTasks.Columns.Add(new DataGridViewCheckBoxColumn
            {
                DataPropertyName = "IsCompleted",
                HeaderText = "Выполнено",
                Width = 60
            });
        }


        private void LoadTasksFromDatabase()
        {
            try
            {
                tasks = DBHelper.GetTasksByUserId(currentUser.UserId);
                dgvTasks.DataSource = tasks;
                UpdateStatus($"Загружено задач: {tasks.Count}");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки задач из базы данных: {ex.Message}",
                    "Ошибка",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
        }

        private void UpdateStatus(string message)
        {
            lblStatus.Text = message;
        }

        private void btnAddTask_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtTaskName.Text))
            {
                MessageBox.Show("Введите название задачи", "Внимание",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);
                return;
            }

            try
            {
                var newTask = new Models.Task
                {
                    Name = txtTaskName.Text.Trim(),
                    Priority = cmbPriority.SelectedItem.ToString(),
                    DueDate = dtpDueDate.Value,
                    IsCompleted = false
                };

                if (DBHelper.AddTask(newTask, currentUser.UserId))
                {
                    LoadTasksFromDatabase();
                    UpdateStatus($"Добавлена задача: {newTask.Name}");
                    ClearInputFields();
                    MessageBox.Show("Задача успешно добавлена!", "Успех",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Information);
                }
                else
                {
                    MessageBox.Show("Не удалось добавить задачу в базу данных", "Ошибка",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при добавлении задачи: {ex.Message}", "Ошибка",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
        }

        private void ClearInputFields()
        {
            txtTaskName.Clear();
            cmbPriority.SelectedIndex = 1;
            dtpDueDate.Value = DateTime.Now.AddDays(1);
        }

        public static string ConnectionString = "Data Source=DJ-R118C03\\SQLEXPRESS;Initial Catalog=UserManagement;Integrated Security=True;Encrypt=False";

        private void btnDeleteTask_Click(object sender, EventArgs e)
        {
            if (dgvTasks.SelectedRows.Count > 0)
            {
                var selectedTask = (Models.Task)dgvTasks.SelectedRows[0].DataBoundItem;

                if (MessageBox.Show($"Удалить задачу: {selectedTask.Name}?",
                    "Подтверждение удаления",
                    MessageBoxButtons.YesNo,
                    MessageBoxIcon.Question) == DialogResult.Yes)
                {

                    using (var connection = new SqlConnection(ConnectionString))
                    {
                        connection.Open();

                        string sqlQuery = "DELETE FROM Tasks WHERE TaskId = @taskId";

                        using (var command = new SqlCommand(sqlQuery, connection))
                        {
                            command.Parameters.AddWithValue("@taskId", value: selectedTask.TaskId);
                            command.ExecuteNonQuery();
                        }
                    }
                }
            }
            else
            {
                MessageBox.Show("Выберите задачу для удаления", "Внимание");
            }
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            LoadTasksFromDatabase();
        }

        private void dgvTasks_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {
            if (e.ColumnIndex == dgvTasks.Columns["IsCompleted"].Index)
            {
                var task = (Models.Task)dgvTasks.Rows[e.RowIndex].DataBoundItem;
                UpdateStatus($"Статус задачи изменён: {task.Name}");
            }
        }

        private void TaskManagementForm_Load(object sender, EventArgs e)
        {

        }
    }
}
